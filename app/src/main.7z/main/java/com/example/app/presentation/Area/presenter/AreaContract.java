package com.example.app.presentation.Area.presenter;

public interface AreaContract {
}
